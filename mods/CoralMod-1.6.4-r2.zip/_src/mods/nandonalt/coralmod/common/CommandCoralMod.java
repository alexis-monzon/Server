package mods.nandonalt.coralmod.common;

import static net.minecraft.util.EnumChatFormatting.GREEN;
import static net.minecraft.util.EnumChatFormatting.WHITE;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.ChatMessageComponent;
import net.minecraft.util.MathHelper;
import cpw.mods.fml.common.Mod;

public class CommandCoralMod extends CommandBase {

	@Override
	public String getCommandName() {
		return "coralmod";
	}

	@Override
	public void processCommand(ICommandSender sender, String[] args) {
		if(args.length < 1) {
			final Mod annotation = CoralMod.class.getAnnotation(Mod.class);
			sendChatToPlayer(sender, annotation.name() + ", v" + annotation.version());
		} else {
         if(args[0].equals("biomes")) {
            String s = "Biomes: ";
            if(CoralMod.instance.settingsManager.getBooleanValue("settings", "oceanonly")) {
               s += "Ocean only";
            } else {
               String biomes = CoralMod.instance.settingsManager.getValue("generation", "biomes");
               String[] biomesArray = biomes.split(",");
      
               // HAXX (..but why is this necessary?)
               if(biomesArray.length == 1) {
                  if(biomesArray[0].isEmpty()) {
                     biomesArray = new String[0];
                  }
               }
               
               if(biomesArray.length == 0) {
                  s += "All";
               } else {
                  s += biomes;
               }
            }
            sendChatToPlayer(sender, s);
			} else if(args[0].equals("regen")) {
				EntityPlayerMP player = getCommandSenderAsPlayer(sender);
				Random random = new Random(player.worldObj.getSeed());
            final int posX = MathHelper.floor_double(player.posX);
            final int posZ = MathHelper.floor_double(player.posZ);
				final int chunkX = posX >> 4;
				final int chunkZ = posZ >> 4;
				final long i = random.nextLong() / 2L * 2L + 1L;
				final long j = random.nextLong() / 2L * 2L + 1L;
				random.setSeed((long)chunkX * i + (long)chunkZ * j ^ player.worldObj.getSeed());
				if(CoralGenerator.generate(random, posX, posZ, player.worldObj)) {
					sendChatToPlayer(sender, "Re-generated coral at: " + chunkX + ", " + chunkZ);
				} else {
					sendChatToPlayer(sender, "Couldn't generate coral at: " + chunkX + ", " + chunkZ);
				}
			} else if(args[0].equals("settings")) {
				sendChatToPlayer(sender, GREEN + "===CoralMod Settings===");
				for(String setting : CoralMod.instance.settingsManager.getNames("settings")) {
					sendChatToPlayer(sender, GREEN + setting + ": " + WHITE + CoralMod.instance.settingsManager.getValue("settings", setting));
				}
			} else if(CoralMod.instance.settingsManager.getNames("settings").contains(args[0])) {
				if(CoralMod.instance.settingsManager.toggle("settings", args[0])) {
					sendChatToPlayer(sender, args[0] + ": " + CoralMod.instance.settingsManager.getValue("settings", args[0]));
					CoralMod.instance.settingsManager.updateSettings();
				} else {
					sendChatToPlayer(sender, "Couldn't toggle " + args[0]);
				}
			} else {
				throw new WrongUsageException("[biomes|regen|settings|SETTING]", new Object[0]);
			}
		}
	}

	private void sendChatToPlayer(ICommandSender sender, String msg) {
		sender.sendChatToPlayer(ChatMessageComponent.createFromText(msg));
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List addTabCompletionOptions(ICommandSender sender, String[] args) {
		List<String> tabCompletionOptions = new ArrayList<String>();
		tabCompletionOptions.addAll(CoralMod.instance.settingsManager.getNames("settings"));
		Collections.sort(tabCompletionOptions);
      tabCompletionOptions.add(0, "biomes");
		tabCompletionOptions.add(1, "regen");
		tabCompletionOptions.add(2, "settings");
		return args.length == 1 ? getListOfStringsFromIterableMatchingLastWord(args, tabCompletionOptions) : null;
	}

	@Override
	public String getCommandUsage(ICommandSender sender) {
		return "/" + getCommandName() + " [regen|settings|SETTING]";
	}
}