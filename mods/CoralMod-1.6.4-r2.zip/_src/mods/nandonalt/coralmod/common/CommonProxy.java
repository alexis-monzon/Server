package mods.nandonalt.coralmod.common;

public class CommonProxy {

	public void clientSetup() {}

}