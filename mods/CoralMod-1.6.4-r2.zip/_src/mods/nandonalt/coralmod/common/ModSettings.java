// TODO: re-write?

package mods.nandonalt.coralmod.common;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import net.minecraftforge.common.Configuration;
import net.minecraftforge.common.Property;

public class ModSettings {

   /**
	 * Configuration
	 */
	private final Configuration config;

   /**
    * Setting map
    */
   private final Map<String, List<LocalProperty>> modSettings = new LinkedHashMap<String, List<LocalProperty>>();
   
   public ModSettings(Configuration config) {
      this.config = config;
   }
   
   /**
    * Register a list of settings
    */
   public void register(String key, List<LocalProperty> list) {
      modSettings.put(key, list);
   }
   
   /**
	 * Get list of setting names
	 */
	public List<String> getNames(String key) {
		List<String> names = new LinkedList<String>();
      List<LocalProperty> list = modSettings.get(key);
      if(list != null) {
         for(LocalProperty prop : list) {
            names.add(prop.getName());
         }
      }
      return names;
	}
   
   /**
    * Gets specified setting
    */
   private LocalProperty getSetting(String key, String s) {
      List<LocalProperty> list = modSettings.get(key);
      for(LocalProperty prop : list) {
         if(prop.getName().equals(s)) {
            return prop;
         }
      }
      return null;
   }
   
   /**
	 * Attempts to toggle specified setting
	 */
	public boolean toggle(String key, String s) {
		if(!getNames(key).contains(s)) {
			CoralMod.log("Unknown setting " + s, true);
			return false;
		}

      LocalProperty prop = getSetting(key, s);
      if(prop == null) {
         return false;
      } else {
         return prop.toggle();
      }
	}

	/**
	 * Attempts to return value of specified setting
	 */
	public String getValue(String key, String s) {
      if(!getNames(key).contains(s)) {
         CoralMod.log("Unknown field " + s, true);
         return "";
      }
      
      LocalProperty prop = getSetting(key, s);
      if(prop == null) {
         return "";
      } else {
         return prop.getString();
      }
	}
   
   /**
    * Set value of specified setting
    */
   public boolean setValue(String key, String s, String value) {
      if(!getNames(key).contains(s)) {
         System.err.println("CoralMod: Unknown field " + s);
         return false;
      }
      
      LocalProperty prop = getSetting(key, s);
      if(prop == null) {
         return false;
      } else {
         prop.set(value);
         return true;
      }
	}
   
   /**
    * Gets boolean value for specified setting
    */
   public boolean getBooleanValue(String key, String s) {
      LocalProperty prop = getSetting(key, s);
      if(prop == null) {
         return false;
      } else {
         return prop.getBoolean(false);
      }
   }
   
   /**
    * Gets integer value for specified setting
    */
   public int getIntValue(String key, String s) {
      LocalProperty prop = getSetting(key, s);
      if(prop == null) {
         return 0;
      } else {
         return prop.getInt();
      }
   }
   
   /**
	 * Attempts to load settings, defaults are used if first time
	 */
	public void loadSettings() {   
      for(String key : modSettings.keySet()) {
         List<LocalProperty> list = modSettings.get(key);
         
         if(list == null) {
            continue;
         }
         
         for(LocalProperty prop : list) {
            Property p = config.get(key, prop.getName(), prop.getDefaultValue(), null, prop.getType());
            prop.set(p.getString());
         }
      }
      
		updateSettings();
	}

	/**
	 * Saves settings
	 */
	public void updateSettings() {
      for(String key : modSettings.keySet()) {
         List<LocalProperty> list = modSettings.get(key);
         
         if(list == null) {
            continue;
         }
         
         for(LocalProperty prop : list) {
            CoralMod.logDebug(key + ": [" + prop.getName() + " = " + prop.getString() + "]");
            Property p = config.get(key, prop.getName(), prop.getDefaultValue(), null, prop.getType());
            p.set(prop.getString());
         }
      }

		config.save();
		CoralMod.log("Saved settings");
	}
   
   public static abstract class LocalProperty extends Property {
      public LocalProperty(String name, String value, Property.Type type) {
         super(name, value, type);
      }
   
      public abstract boolean toggle();
      public abstract String getDefaultValue();
   }
   
   public static class IntProperty extends LocalProperty {
      private final int defaultVal;
      private final int minVal;
      private final int maxVal;
   
      public IntProperty(String name, int defaultVal, int minVal, int maxVal) {
         super(name, Integer.toString(defaultVal), Property.Type.INTEGER);
         this.defaultVal = defaultVal;
         this.minVal = minVal;
         this.maxVal = maxVal;
      }
      
      @Override
      public boolean toggle() {
         if(maxVal < 1 || minVal != 0) {
            return false;
         } else {
            int val = getInt(0);
            val++;
            set(val % (maxVal + 1));
            return true;
         }
      }
      
      @Override
      public String getDefaultValue() {
         return Integer.toString(defaultVal);
      }
      
      @Override
      public void set(String value) {
         try {
            int i = Integer.parseInt(value);
            if(i < minVal || i > maxVal) {
               i = defaultVal;
            }
            super.set(Integer.toString(i));
         } catch (NumberFormatException nfe) {
            super.set(value);
         }
      }
   }
   
   public static class BooleanProperty extends LocalProperty {
      private final boolean defaultVal;
      
      public BooleanProperty(String name, boolean defaultVal) {
         super(name, Boolean.toString(defaultVal), Property.Type.BOOLEAN);
         this.defaultVal = defaultVal;
      }
      
      @Override
      public boolean toggle() {
         boolean bool = Boolean.parseBoolean(getString());
         set(!bool);
         return true;
      }
      
      @Override
      public String getDefaultValue() {
         return Boolean.toString(defaultVal);
      }
   }
   
   public static class StringProperty extends LocalProperty {
      private final String defaultVal;
      
      public StringProperty(String name, String defaultVal) {
         super(name, defaultVal, Property.Type.STRING);
         this.defaultVal = defaultVal;
      }
      
      @Override
      public boolean toggle() {
         return false;
      }
      
      @Override
      public String getDefaultValue() {
         return defaultVal;
      }
   }
   
}