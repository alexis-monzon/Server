// CoralReef Mod

// Original author: Nandonalt
// Current maintainer: q3hardcore

// Special thanks to: fry, OvermindDL1, Mr.okushama

// AtomicStryker - it's  'deprecated', not 'depreciated'

package mods.nandonalt.coralmod.common;

import java.io.File;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

import net.minecraftforge.common.Configuration;
import net.minecraftforge.common.MinecraftForge;

import cpw.mods.fml.common.FMLLog;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.Mod.Instance;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.event.FMLServerStartingEvent;
import cpw.mods.fml.common.network.NetworkMod;
import cpw.mods.fml.common.registry.GameRegistry;

import mods.nandonalt.coralmod.common.ModSettings.BooleanProperty;
import mods.nandonalt.coralmod.common.ModSettings.IntProperty;
import mods.nandonalt.coralmod.common.ModSettings.LocalProperty;
import mods.nandonalt.coralmod.common.ModSettings.StringProperty;

@Mod(modid = "coralmod", name="CoralReef Mod", version="1.6.4r2")
@NetworkMod(clientSideRequired=true, serverSideRequired=false)

public class CoralMod {

	@Instance("coralmod")
   
   /**
    * Mod instance
    */
	public static CoralMod instance;

   @SidedProxy(
      modId="coralmod",
		clientSide="mods.nandonalt.coralmod.client.ClientProxy",
		serverSide="mods.nandonalt.coralmod.common.CommonProxy"
	)
   
	/**
	 * Proxy instance
	 */
	public static CommonProxy proxy;

	// Coral blocks
	protected Block Coral1;
	protected Block Coral2;
	protected Block Coral3;
	protected Block Coral4;
	protected Block Coral5;

	/**
	 * Directory for storing configuration
	 */
	private File configDir;

   public ModSettings settingsManager;
   
   private static Logger logger = Logger.getLogger("CoralMod");
   
	/**
	 * Pre-initialization
	 */
	@EventHandler
	public void preInit(FMLPreInitializationEvent evt) {
		// Set configuration directory
		configDir = new File(evt.getModConfigurationDirectory(), "coralreef");

		// Configure block IDs
		final Configuration blockIDs = new Configuration(new File(configDir, "blockids.cfg"));
		int Coral1ID = blockIDs.getTerrainBlock("block", "Coral1", 178, null).getInt();
		int Coral2ID = blockIDs.getTerrainBlock("block", "Coral2", 179, null).getInt();
		int Coral3ID = blockIDs.getTerrainBlock("block", "Coral3", 180, null).getInt();
		int Coral4ID = blockIDs.getTerrainBlock("block", "Coral4", 177, null).getInt();
		int Coral5ID = blockIDs.getTerrainBlock("block", "Coral5", 176, null).getInt();
		blockIDs.save();

		// Instantiate blocks
		Coral1 = new BlockCoral(Coral1ID, 1);
		Coral1.setHardness(0.2F).setStepSound(Block.soundStoneFootstep).setUnlocalizedName("Coral1");

		Coral2 = new BlockCoral2(Coral2ID, 0);
		Coral2.setHardness(0.5F).setStepSound(Block.soundStoneFootstep).setUnlocalizedName("Coral2");

		Coral3 = new BlockCoral2(Coral3ID, 1);
		Coral3.setHardness(0.5F).setStepSound(Block.soundStoneFootstep).setUnlocalizedName("Coral3");

		Coral4 = new BlockCoral(Coral4ID, 6);
		Coral4.setHardness(0.2F).setStepSound(Block.soundStoneFootstep).setUnlocalizedName("Coral4");

		Coral5 = new BlockCoral(Coral5ID, 6);
		Coral5.setHardness(0.2F).setStepSound(Block.soundStoneFootstep).setLightValue(1.0F).setUnlocalizedName("CoralLightt");

		// Register blocks
		GameRegistry.registerBlock(Coral1, ItemCoral.class, "Coral1");
		GameRegistry.registerBlock(Coral2, "Coral2");
		GameRegistry.registerBlock(Coral3, "Coral3");
		GameRegistry.registerBlock(Coral4, ItemCoral.class, "Coral4");
		GameRegistry.registerBlock(Coral5, ItemCoral.class, "Coral5");

		// Add recipes
		addRecipes();
	}

	/**
	 * Initialize
	 */
	@EventHandler
	public void init(FMLInitializationEvent evt) {
      // Experimental settings stuff
      Configuration config = new Configuration(new File(configDir, "settings.cfg"));
      settingsManager = new ModSettings(config);
      
      List<LocalProperty> settings = new LinkedList<LocalProperty>();
      settings.add(new BooleanProperty("coralgen", true));
      settings.add(new BooleanProperty("spikyenabled", true));
      settings.add(new BooleanProperty("enablebubbles", true));
      settings.add(new BooleanProperty("enablegrow", false));
      settings.add(new IntProperty("avgsize", 1, 0, 2));
      settings.add(new BooleanProperty("oceanonly", true));
      settings.add(new BooleanProperty("land", false));
      settings.add(new BooleanProperty("alldimensions", false));
      settings.add(new BooleanProperty("light", true));
      settings.add(new BooleanProperty("air", false));
      settings.add(new BooleanProperty("debug", false));
      settingsManager.register("settings", settings);
      
      List<LocalProperty> genSettings = new LinkedList<LocalProperty>();
      genSettings.add(new IntProperty("baseheight", 0, 0, 64));
      genSettings.add(new IntProperty("heightoffset", 128, 4, 256));
      genSettings.add(new IntProperty("iterationfactor", 10, 0, 12));
      genSettings.add(new IntProperty("radius", 16, 0, 16));
      genSettings.add(new StringProperty("biomes", ""));
      settingsManager.register("generation", genSettings);
      
      settingsManager.loadSettings();
      
		// Client setup
		proxy.clientSetup();

		// Register world generation hook
		MinecraftForge.EVENT_BUS.register(new CoralGenerator());
	}
   
	/**
	 * Register command
	 */
	@EventHandler
	public void severStarting(FMLServerStartingEvent evt) {
		evt.registerServerCommand(new CommandCoralMod());
	}

	/**
	 * Adds dye recipes for coral
	 */
	private void addRecipes() {
		Item dye = Item.dyePowder;
		GameRegistry.addRecipe(new ItemStack(dye, 1, 14), new Object[]{"B", 'B', new ItemStack(Coral1, 1, 0)});
		GameRegistry.addRecipe(new ItemStack(dye, 1, 10), new Object[]{"B", 'B', new ItemStack(Coral1, 1, 1)});
		GameRegistry.addRecipe(new ItemStack(dye, 1, 13), new Object[]{"B", 'B', new ItemStack(Coral1, 1, 2)});
		GameRegistry.addRecipe(new ItemStack(dye, 1, 9), new Object[]{"B", 'B', new ItemStack(Coral4, 1, 3)});
		GameRegistry.addRecipe(new ItemStack(dye, 1, 3), new Object[]{"B", 'B', new ItemStack(Coral1, 1, 4)});
		GameRegistry.addRecipe(new ItemStack(dye, 1, 6), new Object[]{"B", 'B', new ItemStack(Coral5, 1, 5)});
	}

   // ===== TODO: re-write this section =====
   
   /**
    * Checks if it's safe to place coral
    */
   public boolean checkPlace(World world, int x, int y, int z, boolean stationary) {
      boolean b = checkWater(world, x, y, z, stationary);
      if(b) {
         return true;
      }
      int blockID = world.getBlockId(x, y, z);
      if(blockID == 0 && instance.settingsManager.getBooleanValue("settings", "land")) {
         return true;
      }
      return false;
   }
   
	/**
	 * Checks if a block is water and if it's stationary
	 */
	public boolean checkWater(World world, int x, int y, int z, boolean stationary) {
		if(checkWater(world, x, y, z)) {
			int blockID = world.getBlockId(x, y, z);
			if(blockID > 0 && blockID < Block.blocksList.length) {
				Block waterBlock = Block.blocksList[blockID];
				if(waterBlock != null) {
					boolean waterStationary = waterBlock.func_82506_l();
					return waterStationary == stationary;
				}
			}
         return false;
		} else {
			return false;
		}
	}

	/**
	 * Checks if a block is water
	 */
	public boolean checkWater(World world, int x, int y, int z) {
		int blockID = world.getBlockId(x, y, z);

		// if the block is any type of coral, it's not water
      if(checkCoral(world, x, y, z)) {
         return false;
      }

      if(world.getBlockMaterial(x, y, z) == Material.water) {
         return true;
		}
      
		return false;
	}

   /**
    * Checks if a block is coral
    */
   public boolean checkCoral(World world, int x, int y, int z) {
      int blockID = world.getBlockId(x, y, z);
      
      if(blockID == Coral1.blockID || blockID == Coral2.blockID || blockID == Coral3.blockID 
		|| blockID == Coral4.blockID || blockID == Coral5.blockID) {
			return true;
		} else {
         return false;
      }
   }

   // ===== END: re-write this section =====
   
   public static void log(String s, boolean warning) {
      logger.log(warning ? Level.WARNING : Level.INFO, s);
   }

   public static void log(String s) {
      log(s, false);
   }
   
   public static void logDebug(String s) {
      if(instance.settingsManager.getBooleanValue("settings", "debug")) {
         log(s);
      }
   }
   
   static {
      logger.setParent(FMLLog.getLogger());
   }
   
}
