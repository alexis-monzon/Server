package mods.nandonalt.coralmod.client;

import mods.nandonalt.coralmod.common.CoralMod;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSmallButton;
import net.minecraft.client.resources.I18n;

import org.lwjgl.input.Keyboard;

import java.util.List;

public class GuiCoralReef extends GuiScreen {

   /**
    * Array of strings corresponding to size values
    */
	public static final String[] SIZES = new String[] {"small", "normal", "large"};

   /**
    * Parent GUI Screen
    */
   private final GuiScreen parentGuiScreen;
   
   public GuiCoralReef(GuiScreen parentGuiScreen) {
      this.parentGuiScreen = parentGuiScreen;
   }
   
	/**
	 * Gets the description for button with specified index
	 */
	private String getDesc(int index) {
      List<String> list = getSettings();
		final String desc;
		if(index >= 0 && index < list.size()) {
			desc = I18n.getString("coralmod.settings." + list.get(index));
		} else {
			desc = I18n.getString("coralmod.settings.unimplemented");
		}
		return desc + ": " + getState(index);
	}

   /**
    * Gets the field for button with specified index
    */
	private String getField(int index) {
      List<String> list = getSettings();
		final String field;
		if(index >= 0 && index < list.size()) {
			field = list.get(index);
		} else {
			field = "debug"; // default
		}
		return field;
	}

	/**
	 * Adds the buttons (and other controls) to the screen in question.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void initGui() {
      List<String> list = getSettings();
		for(int i = 0; i < list.size(); i++) {
			buttonList.add(new GuiSmallButton(i, width / 2 - 155 + i % 2 * 160, height / 6 + 24 * (i >> 1), getDesc(i)));
		}

      int j = buttonList.size();
      if(j % 2 == 1) {
         j++;
      }
      j += 2;
      
      final String s;
		if(isInGame()) {
         s = I18n.getString("menu.returnToGame");
      } else {
         s = I18n.getString("gui.done");
      }
      
      buttonList.add(new GuiButton(-1, width / 2 - 100, height / 6 + 24 * (j >> 1), s));
	}

	/**
	 * Gets the current state of the button's setting
	 */
	private String getState(int index) {
		String field = getField(index);
		String state = CoralMod.instance.settingsManager.getValue("settings", field);
		try {
			int size = Integer.parseInt(state);
			if(size >= 0 && size < SIZES.length) {
				return I18n.getString("options.guiScale." + SIZES[size]);
			} else {
				CoralMod.log(field + " has an unsupported value", true);
				return state;
			}
		} catch (NumberFormatException nfe) {
			Boolean bool = Boolean.parseBoolean(state);
			if(bool) {
				return I18n.getString("options.on");
			} else {
				return I18n.getString("options.off");
			}
		}
	}

	/**
	 * Fired when a key is typed. This is the equivalent of KeyListener.keyTyped(KeyEvent e).
	 */
	@Override
	protected void keyTyped(char character, int key) {
		if (key == Keyboard.KEY_ESCAPE) {
			CoralMod.instance.settingsManager.updateSettings();
		}
		super.keyTyped(character, key);
	}

	/**
	 * Fired when a control is clicked. This is the equivalent of ActionListener.actionPerformed(ActionEvent e).
	 */
	@Override
	protected void actionPerformed(GuiButton guiButton) {
      if(!guiButton.enabled) {
         return;
      }
   
      List<String> list = getSettings();
		if(guiButton.id >= 0 && guiButton.id < list.size()) {
			CoralMod.instance.settingsManager.toggle("settings", getField(guiButton.id));
			guiButton.displayString = getDesc(guiButton.id);
		} else {
			if(isInGame()) {
				mc.displayGuiScreen((GuiScreen)null);
				mc.setIngameFocus();
			} else {
            mc.displayGuiScreen(parentGuiScreen);;
			}
			CoralMod.instance.settingsManager.updateSettings();
		}
	}

	/**
	 * Draws the screen and all the components in it.
	 */
	@Override
	public void drawScreen(int mouseX, int mouseY, float renderPartialTicks) {
		drawDefaultBackground();

      final String status;
		if(!isInGame()) {
			status = I18n.getString("options.title");
		} else if(!mc.isSingleplayer()) {
			status = I18n.getString("coralmod.settings.disabled");
		} else {
         status = I18n.getString("coralmod.settings.enabled");
      }

      final String screenTitle = I18n.getString("coralmod.settings.title") + " (" + status + ")";
      drawCenteredString(fontRenderer, screenTitle, width / 2, 20, 16777215);

		super.drawScreen(mouseX, mouseY, renderPartialTicks);
	}

   /**
    * Checks if the player is currently in-game
    */
	public boolean isInGame() {
      return parentGuiScreen == null;
	}

   /**
    * Returns a list of settings
    */
   public List<String> getSettings() {
      return CoralMod.instance.settingsManager.getNames("settings");
   }
   
}
