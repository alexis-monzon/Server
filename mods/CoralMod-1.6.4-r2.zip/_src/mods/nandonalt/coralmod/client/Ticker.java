// Somewhat stolen from Binds by Mr.okushama
// http://www.minecraftforum.net/topic/2184193-

package mods.nandonalt.coralmod.client;

import java.util.EnumSet;

import cpw.mods.fml.client.FMLClientHandler;
import cpw.mods.fml.common.ITickHandler;
import cpw.mods.fml.common.TickType;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiOptions;

import org.lwjgl.input.Keyboard;

public class Ticker implements ITickHandler {

	@Override
	public void tickStart(EnumSet<TickType> type, Object... tickData) {
		if(type.equals(EnumSet.of(TickType.CLIENT))){
         Minecraft mc = FMLClientHandler.instance().getClient();
         
         if(mc == null || !Keyboard.isCreated()) {
            return;
			}
         
			if(mc.currentScreen instanceof GuiOptions) {
				if(Keyboard.isKeyDown(CoralKeyHandler.binding.keyCode)) {
               mc.displayGuiScreen(new GuiCoralReef(mc.currentScreen));
            }
			}
		}
	}

	@Override
	public void tickEnd(EnumSet<TickType> type, Object... tickData) {
	
	}

	@Override
	public EnumSet<TickType> ticks() {
		return EnumSet.of(TickType.CLIENT);
	}

	@Override
	public String getLabel() {
		return "CoralMod Ticker";
	}

}
